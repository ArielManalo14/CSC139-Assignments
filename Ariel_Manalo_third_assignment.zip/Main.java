import java.io.*;
import java.util.*;
/*
Ariel Manalo
CSC139 Section 1
Assignment 3
 */

public class Main {

  public static void main(String[] args) throws IOException {
    /*
     * variables for the information given from the input file
     */
    String alg;
    int timeQuantum;
    int totalProcesses;

    /*
     * created a writer so i can write to the output file
     * 
     * created a scanner so that i can read from the input file
     */
    BufferedWriter writer = null;
    File file = new File("input.txt");
    Scanner scan = new Scanner(file);

    try {
      writer = new BufferedWriter(new FileWriter("output.txt"));
      assert writer != null;

      alg = scan.next();
      /*
       * since the first complete token is the name of the algorithm,
       * I used that to create the following conditional statements.
       * 
       * It checks for which algorithm it is, then it takes the information
       * needed for that certain algorithm. Then it calls the matching
       * method for that algorithm.
       * 
       * I decided to use a 2D array to fill in the information of
       * each process. My 2D array has 4 columns that stand for
       * process number, arrival time, cpu burst time, and priority.
       * The amount of rows is based off of how many processes there are.
       */
      if (Objects.equals(alg, "RR")) {
        timeQuantum = scan.nextInt();
        totalProcesses = scan.nextInt();
        int[][] processArr = new int[totalProcesses][4];
        for (int i = 0; i < processArr.length; i++) {
          for (int j = 0; j < processArr[i].length; j++) {
            processArr[i][j] = scan.nextInt();
          }
        }
        RRmethod(processArr, timeQuantum, totalProcesses, alg, writer);

      } else if (Objects.equals(alg, "SJF")) {
        totalProcesses = scan.nextInt();
        int[][] processArr = new int[totalProcesses][4];
        for (int i = 0; i < processArr.length; i++) {
          for (int j = 0; j < processArr[i].length; j++) {
            processArr[i][j] = scan.nextInt();
          }
        }
        SJFmethod(processArr, totalProcesses, alg, writer);

      } else if (Objects.equals(alg, "PR_noPREMP")) {
        totalProcesses = scan.nextInt();
        int[][] processArr = new int[totalProcesses][4];
        for (int i = 0; i < processArr.length; i++) {
          for (int j = 0; j < processArr[i].length; j++) {
            processArr[i][j] = scan.nextInt();
          }
        }
        PR_noPREMPmethod(processArr, totalProcesses, alg, writer);

      } else if (Objects.equals(alg, "PR_withPREMP")) {
        totalProcesses = scan.nextInt();
        int[][] processArr = new int[totalProcesses][4];
        for (int i = 0; i < processArr.length; i++) {
          for (int j = 0; j < processArr[i].length; j++) {
            processArr[i][j] = scan.nextInt();
          }
        }
        PR_withPREMPmethod(processArr, totalProcesses, alg, writer);

      } else {
        System.out.println("ERROR: NOT VALID ALGORITHM");
      }
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static void RRmethod(int[][] arr, int timeQuantum, int totalProcesses, String alg, BufferedWriter writer)
      throws IOException {
    /*
     * method for Round Robin
     */
    System.out.println(alg + " " + timeQuantum);
    writer.write(alg + " " + timeQuantum);

    /*
     * used a queue to keep track of which processes are ready
     * 
     * these are my variable that im going to be using throughout
     * the method
     */
    Queue<Integer> processesReady = new LinkedList<>();
    int sum = 0;
    double waitingTime = 0;
    boolean keepGoing = true;
    int doneProcesses = 0;
    int peeked;
    int time = 0;

    /*
     * this calls a separate method that sorts the passed through
     * 2D array by the arrival time
     */
    sortbyColumn(arr, 1);

    for (int i = 0; i < arr.length; i++) {
      /*
       * adds the processes in the order they arrived into the queue
       */
      processesReady.add(arr[i][0]);
    }
    while (keepGoing) {
      if (doneProcesses == totalProcesses) {
        /*
         * breaks out of the while loop once all processes are done
         */
        keepGoing = false;
      }
      while (!processesReady.isEmpty()) {
        /*
         * this takes the element thats at the front of the queue.
         * 
         * this represents when a process gets the cpu
         */
        peeked = processesReady.peek();
        System.out.println(time + " " + peeked);
        writer.write("\n" + time + " " + peeked);

        /*
         * calculating part of the waiting time
         */
        sum = sum + (time - arr[peeked - 1][1]);

        /*
         * the following is checking if the process finished
         * or if it was cut off by the time quantum
         * 
         * if the cpu burst is less than the time quantum,
         * the time will increment by the cpu burst
         * 
         * if the cpu burst is greater than or equal to the
         * time quantum, the time will increment by the
         * time quantum
         */
        if (arr[peeked - 1][2] < timeQuantum) {
          time = time + arr[peeked - 1][2];
        } else {
          time = time + timeQuantum;
        }

        /*
         * updates the cpu burst of the process
         * 
         * then removes it from the queue
         */
        arr[peeked - 1][2] = arr[peeked - 1][2] - timeQuantum;
        processesReady.remove();

        /*
         * the following checks if the process has completed its
         * cpu burst or not.
         * 
         * if it finished, it increments doneProcesses, if not, it
         * adds its back into the queue
         */
        if (arr[peeked - 1][2] <= 0) {

          doneProcesses++;
        } else {
          processesReady.add(peeked);
          arr[peeked - 1][1] = time;
        }
      }
    }
    /*
     * calculating waiting time
     */
    waitingTime = (double) sum / (double) totalProcesses;
    System.out.println("AVG Waiting Time: " + waitingTime);
    writer.write("\n" + "AVG Waiting Time: " + waitingTime);
  }

  public static void SJFmethod(int[][] arr, int totalProcesses, String alg, BufferedWriter writer) throws IOException {
    /*
     * method for shortest job first
     */
    System.out.println(alg);
    writer.write(alg);

    /*
     * decided to use a list and a queue for this method. the list will have the
     * methods that have arrived
     * and the queue will put the processes in order of who has the shortest cpu
     * burst
     * 
     * below are variables i use throughout the method
     */
    List<Integer> here = new ArrayList<>();
    Queue<Integer> ready = new LinkedList<>();
    int currTime = 0;
    int peeked;
    int doneProcesses = 0;
    int min;
    int nowProcess;
    int sum = 0;
    double waitingTime;

    while (doneProcesses < totalProcesses) {
      for (int i = 0; i < arr.length; i++) {
        if (arr[i][1] <= currTime && arr[i][2] > 0) {
          /*
           * this is checking if the process has arrived and if the
           * cpu burst is not zero. if so, the process will be added
           * to the list
           */
          here.add(arr[i][0]);
        }
      }
      while (!here.isEmpty()) {
        /*
         * below is calculating which process has the shortest cpu burst.
         * it then adds that process into the queue
         */
        min = here.get(0);
        nowProcess = 0;
        for (int i = 0; i < here.size(); i++) {
          if (arr[here.get(i) - 1][2] < arr[min - 1][2]) {
            min = arr[here.get(i) - 1][0];
            nowProcess = arr[here.get(i) - 1][0];
          } else if (arr[here.get(i) - 1][2] == arr[min - 1][2]) {
            if (arr[here.get(i) - 1][1] < arr[min - 1][1]) {
              min = arr[here.get(i) - 1][0];
              nowProcess = arr[here.get(i) - 1][0];
            } else {
              min = arr[min - 1][0];
              nowProcess = arr[min - 1][0];
            }
          }
        }
        ready.add(nowProcess);
        while (!ready.isEmpty()) {
          /*
           * this takes the process thats at the front of the queue.
           * this represents the process getting the cpu
           */
          peeked = ready.poll();
          System.out.println(currTime + " " + peeked);
          writer.write("\n" + currTime + " " + peeked);
          sum = sum + (currTime - arr[peeked - 1][1]);
          currTime = currTime + arr[peeked - 1][2];
          arr[peeked - 1][2] = 0;
          here.clear();
          doneProcesses++;
        }
      }
    }
    /*
     * calculating waiting time
     */
    waitingTime = (double) sum / (double) totalProcesses;
    System.out.println("AVG Waiting Time: " + waitingTime);
    writer.write("\n" + "AVG Waiting Time: " + waitingTime);
  }

  public static void PR_noPREMPmethod(int[][] arr, int totalProcesses, String alg, BufferedWriter writer)
      throws IOException {
    /*
     * method for PR_noPREMP
     */
    System.out.println(alg);
    writer.write(alg);

    /*
     * this method is very similar to the SFJ method so I used the same data
     * structures and variables.
     * 
     * the main difference between this method is that where im finding the minimum
     * cpu burst,
     * i am finding the highest priority instead
     */
    List<Integer> here = new ArrayList<>();
    Queue<Integer> ready = new LinkedList<>();
    int currTime = 0;
    int peeked;
    int doneProcesses = 0;
    int min;
    int nowProcess;
    int sum = 0;
    double waitingTime;

    while (doneProcesses < totalProcesses) {
      for (int i = 0; i < arr.length; i++) {
        if (arr[i][1] <= currTime && arr[i][2] > 0) {
          here.add(arr[i][0]);
        }
      }
      while (!here.isEmpty()) {
        /*
         * this is where this method differs from the SFJ
         */
        min = here.get(0);
        nowProcess = 0;
        for (int i = 0; i < here.size(); i++) {
          if (arr[here.get(i) - 1][3] < arr[min - 1][3]) {
            min = arr[here.get(i) - 1][0];
            nowProcess = arr[here.get(i) - 1][0];
          } else if (arr[here.get(i) - 1][3] == arr[min - 1][3]) {
            if (arr[here.get(i) - 1][0] < arr[min - 1][0]) {
              min = arr[here.get(i) - 1][0];
              nowProcess = arr[here.get(i) - 1][0];
            } else {
              min = arr[min - 1][0];
              nowProcess = arr[min - 1][0];
            }
          }
        }
        ready.add(nowProcess);
        while (!ready.isEmpty()) {
          peeked = ready.poll();
          System.out.println(currTime + " " + peeked);
          writer.write("\n" + currTime + " " + peeked);
          sum = sum + (currTime - arr[peeked - 1][1]);
          currTime = currTime + arr[peeked - 1][2];
          arr[peeked - 1][2] = 0;
          here.clear();
          doneProcesses++;
        }
      }
    }
    /*
     * calculating waiting time
     */
    waitingTime = (double) sum / (double) totalProcesses;
    System.out.println("AVG Waiting Time: " + waitingTime);
    writer.write("\n" + "AVG Waiting Time: " + waitingTime);
  }

  public static void PR_withPREMPmethod(int[][] arr, int totalProcesses, String alg, BufferedWriter writer)
      throws IOException {
    /*
     * method for PR_withPREM
     */
    System.out.println(alg);
    writer.write(alg);

    /*
     * i used the same data structures as the previous methods,
     * along with the same variables, except i added a now2process
     * variable so i could check whether or not the cpu was given
     * to a different proceess when a new process arrives
     */
    List<Integer> here = new ArrayList<>();
    Queue<Integer> ready = new LinkedList<>();
    int currTime = 0;
    int doneProcesses = 0;
    int min;
    int nowProcess;
    int now2Process = 0;
    boolean keepGoing = true;
    int sum = 0;
    double waitingTime;

    while (keepGoing) {
      if (doneProcesses == totalProcesses) {
        keepGoing = false;
      }
      for (int i = 0; i < arr.length; i++) {
        if (arr[i][1] <= currTime && arr[i][2] > 0) {
          /*
           * similar to the last two methods, this checks if the process
           * arrived and its cpu burst is not zero. if so, it adds the
           * process to the list
           */
          here.add(arr[i][0]);
        }
      }
      while (!here.isEmpty()) {
        /*
         * similar to the last method, i had to find the process with
         * the highest priority and add it to the queue
         */
        min = here.get(0);
        nowProcess = 0;
        for (int i = 0; i < here.size(); i++) {
          if (arr[here.get(i) - 1][3] < arr[min - 1][3]) {
            min = arr[here.get(i) - 1][0];
            nowProcess = arr[here.get(i) - 1][0];
          } else if (arr[here.get(i) - 1][3] == arr[min - 1][3]) {
            if (arr[here.get(i) - 1][0] < arr[min - 1][0]) {
              min = arr[here.get(i) - 1][0];
              nowProcess = arr[here.get(i) - 1][0];
            } else {
              min = arr[min - 1][0];
              nowProcess = arr[min - 1][0];
            }
          }
        }
        if (nowProcess != now2Process) {
          /*
           * this checks if a new process got the cpu.
           * 
           * if the now2process is not equal to the nowprocess,
           * that means that a new process is on the cpu
           * 
           * if so, then i print out that that new process
           * got the cpu
           */
          if (now2Process != 0) {
            arr[now2Process - 1][1] = currTime;
          }
          System.out.println(currTime + " " + nowProcess);
          writer.write("\n" + currTime + " " + nowProcess);
          sum = sum + (currTime - arr[nowProcess - 1][1]);
        }
        currTime++;
        arr[nowProcess - 1][2] = arr[nowProcess - 1][2] - 1;
        if (arr[nowProcess - 1][2] == 0) {
          /*
           * checks if that process is done
           */
          doneProcesses++;
        }
        now2Process = nowProcess;
        here.clear();
      }
    }
    /*
     * calculating waiting time
     */
    waitingTime = (double) sum / (double) totalProcesses;
    System.out.println("AVG Waiting Time: " + waitingTime);
    writer.write("\n" + "AVG Waiting Time: " + waitingTime);
  }

  public static void sortbyColumn(int arr[][], int col) {
    /*
     * separate method that was called in Round Robin to help
     * me sort my 2D array
     */
    Arrays.sort(arr, (a, b) -> Integer.compare(a[col], b[col]));
  }
}
import java.io.*;
import java.util.*;
/*
Ariel Manalo
CSC139 Section 1
Assignment 4
 */

public class Main {

    public static void main(String[] args) throws IOException {

        int pages;
        int frames;
        int requests;

        BufferedWriter writer = null;
        File file = new File("input.txt");
        Scanner scan = new Scanner(file);

        try {
            writer = new BufferedWriter(new FileWriter("output.txt"));
            assert writer != null;

            pages = scan.nextInt();
            frames = scan.nextInt();
            requests = scan.nextInt();

            int[][] requestsArr = new int[requests][2];
            for (int i = 0; i < requestsArr.length; i++) {
                for (int j = 0; j < requestsArr[i].length; j++) {
                    requestsArr[i][j] = scan.nextInt();
                }
            }
            writer.write(Arrays.deepToString(requestsArr));

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void FIFO_method(int pages, int frames, int requests, BufferedWriter writer) throws IOException {
        writer.write("\nFIFO");

        int pageFaults = 0;
    }

    public static void Optimal_method(int pages, int frames, int requests, BufferedWriter writer) throws IOException {
        writer.write("\nOptimal");

        int pageFaults = 0;
    }

    public static void LRU_method(int pages, int frames, int requests, BufferedWriter writer) throws IOException {
        writer.write("\nLRU");

        int pageFaults = 0;
    }
}